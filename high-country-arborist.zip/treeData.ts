import { Tree, MonthData, MonthStatus } from './types';

const rawData = `Valley Nursery,Ornamental/Shade,Ash,Autumn Purple,Fraxinus americana 'Autumn Purple',50,30,Multi,Moderate,Shade tree; reliable fall color. PROHIBITED in ROW per GJ Forestry Board (Ash species).,No (Prohibited)
Valley Nursery,Ornamental/Shade,Ash,Marshall,Fraxinus pennsylvanica 'Marshall',50,40,Gold,Moderate,Fast growing; hardy. PROHIBITED in ROW per GJ Forestry Board (Ash species).,No (Prohibited)
Valley Nursery,Ornamental/Shade,Ash,Patmore,Fraxinus pennsylvanica 'Patmore',50,35,Gold,Moderate,Hardy; uniform shape. PROHIBITED in ROW per GJ Forestry Board (Ash species).,No (Prohibited)
Valley Nursery,Ornamental/Shade,Ash,Summit,Fraxinus pennsylvanica 'Summit',50,25,Gold,Moderate,Narrower form; uniform. PROHIBITED in ROW per GJ Forestry Board (Ash species).,No (Prohibited)
Valley Nursery,Ornamental/Shade,Boxelder,Sensation,Acer negundo 'Sensation',30,25,Red/Orange,Low-Med,Seedless male clone; fast growing; tolerates poor soil. Approved street tree.,Yes
Valley Nursery,Ornamental/Shade,Chokecherry,Canada Red (Schubert),Prunus virginiana 'Schubert',25,20,Reddish Purple,Low-Med,Native heritage; bird habitat; purple foliage. Non-suckering cultivar approved.,Yes
Valley Nursery,Ornamental/Shade,Crabapple,Radiant,Malus 'Radiant',20,20,N/A,Moderate,Pollinator; Bright red ½ inch fruit. Check with City Forester for acceptable cultivars.,Yes (Verify Cultivar)
Valley Nursery,Ornamental/Shade,Crabapple,Spring Snow,Malus 'Spring Snow',20,20,N/A,Moderate,Pollinator (Sterile); Fruitless; White flowers. Check with City Forester for acceptable cultivars.,Yes (Verify Cultivar)
Valley Nursery,Ornamental/Shade,Crabapple,Prairie Fire,Malus 'Prairifire',20,20,Orange-Red,Moderate,Pollinator; Dark red ½ inch fruit. Check with City Forester for acceptable cultivars.,Yes (Verify Cultivar)
Valley Nursery,Ornamental/Shade,Crabapple,Royal Raindrop,Malus 'Royal Raindrops',20,20,Copper-Red,Moderate,Pollinator; Red ¼ inch fruit. Check with City Forester for acceptable cultivars.,Yes (Verify Cultivar)
Valley Nursery,Ornamental/Shade,Crabapple,Perfect Purple,Malus 'Perfect Purple',20,20,Red,Moderate,Pollinator; Purple red fruit. Check with City Forester for acceptable cultivars.,Yes (Verify Cultivar)
Valley Nursery,Ornamental/Shade,Goldenrain Tree,Standard,Koelreuteria paniculata,30,30,Yellow,Low (Xeric),Summer blooms; lantern-like pods; heat tolerant. Volunteer seedlings can be an issue.,Yes
Valley Nursery,Ornamental/Shade,Hackberry,Common,Celtis occidentalis/reticulata,75,50,Yellow,Low-Med,Native capabilities; tough shade tree. Tolerant of urban conditions.,Yes
Valley Nursery,Ornamental/Shade,Hawthorn,Russian,Crataegus ambigua,18,18,N/A,Low (Xeric),White flower; red fruit; tough structure. Tolerant of alkaline soil.,Yes
Valley Nursery,Ornamental/Shade,Hawthorn,Thornless Cockspur,Crataegus crus-galli var. inermis,15,15,Bronze/Red,Low-Med,Small white flower; horizontal branching. Fruit litter may be an issue.,Yes
Valley Nursery,Ornamental/Shade,Hawthorn,Winter King,Crataegus viridis 'Winter King',25,25,Gold/Red,Low-Med,White flower; red fruit persists. Mostly spineless.,Yes
Valley Nursery,Ornamental/Shade,Hawthorn,Washington,Crataegus phaenopyrum,25,20,Orange/Red,Low-Med,Bright red fruit; thorns. Drought tolerant.,Yes
Valley Nursery,Ornamental/Shade,Honeylocust,Imperial,Gleditsia triacanthos 'Imperial',35,35,Gold,Low-Med,Seedless; filtered shade; compact. Thornless/Fruitless.,Yes
Valley Nursery,Ornamental/Shade,Honeylocust,Shademaster,Gleditsia triacanthos 'Shademaster',50,35,Gold,Low-Med,Seedless; high canopy; fast grower. Thornless/Fruitless.,Yes
Valley Nursery,Ornamental/Shade,Honeylocust,Sunburst,Gleditsia triacanthos 'Sunburst',35,35,Gold,Low-Med,Seedless; yellow new growth. PROHIBITED in ROW per GJ Forestry Board.,No (Prohibited)
Valley Nursery,Ornamental/Shade,Honeylocust,Skyline,Gleditsia triacanthos 'Skyline',45,35,Gold,Low-Med,Seedless; pyramidal shape; strong central leader. Thornless/Fruitless.,Yes
Valley Nursery,Ornamental/Shade,Kentucky Coffeetree,Standard,Gymnocladus dioicus,50,35,Yellow,Low,Drought tolerant; sparse seeds. Tolerant of urban conditions.,Yes
Valley Nursery,Ornamental/Shade,Lilac Tree,Ivory Silk,Syringa reticulata 'Ivory Silk',25,15,N/A,Moderate,Creamy white panicles. Not explicit on approved list; private use recommended.,No (Private Property Only)
Valley Nursery,Ornamental/Shade,Linden,Glenleven,Tilia x flavescens 'Glenleven',40,30,Yellow,Moderate,Fast grower; pyramidal. Not explicit on approved list.,No (Private Property Only)
Valley Nursery,Ornamental/Shade,Linden,Greenspire,Tilia cordata 'Greenspire',40,30,Yellow,Moderate,Formal shape. Not explicit on approved list.,No (Private Property Only)
Valley Nursery,Ornamental/Shade,Linden,Redmond,Tilia americana 'Redmond',40,25,Yellow,Moderate,Large leaves; dense shade. Not explicit on approved list.,No (Private Property Only)
Valley Nursery,Ornamental/Shade,Linden,Sterling Silver,Tilia tomentosa 'Sterling Silver',45,25,Yellow,Moderate,Silvery underside; resists beetles. Not explicit on approved list.,No (Private Property Only)
Valley Nursery,Ornamental/Shade,Maple,Celebration,Acer x freemanii 'Celebration',45,25,Yellow to Orange,Moderate,Fast growing. PROHIBITED in ROW per GJ Forestry Board (Freeman Maple).,No (Prohibited)
Valley Nursery,Ornamental/Shade,Maple,Emerald Queen,Acer platanoides 'Emerald Queen',45,40,Yellow,Moderate,Vigorous grower. Norway Maples susceptible to sunscald; planting restricted to large areas.,Yes (Restricted)
Valley Nursery,Ornamental/Shade,Maple,Deborah,Acer platanoides 'Deborah',45,40,Bronze,Moderate,Red new growth. Norway Maples susceptible to sunscald; planting restricted to large areas.,Yes (Restricted)
Valley Nursery,Ornamental/Shade,Maple,Norwegian Sunset,Acer truncatum x platanoides,35,25,Yellow/Orange/Red,Low-Med,Heat tolerant hybrid; good for smaller spaces. Thin bark damaged easily.,Yes
Valley Nursery,Ornamental/Shade,Maple,Tatarian Hot Wings,Acer tataricum 'Hot Wings',20,20,Yellow/Orange-Red,Low (Xeric),Red samaras look like flowers; tolerant of alkaline soil.,Yes
Valley Nursery,Ornamental/Shade,Maple,Pacific Sunset,Acer truncatum x platanoides,30,25,Yellow/Orange-Red,Low-Med,Glossy foliage; heat tolerant. Thin bark damaged easily.,Yes
Valley Nursery,Ornamental/Shade,Oak,Bur,Quercus macrocarpa,60,60,Yellow-Brown,Low,Taproot; long-lived. Tolerant of urban conditions.,Yes
Valley Nursery,Ornamental/Shade,Oak,Swamp White,Quercus bicolor,50,40,Yellow-Brown,Moderate,Tolerates compacted soil better than most oaks. Chlorosis may be issue.,Yes
Valley Nursery,Ornamental/Shade,Oak,Skyrocket,Quercus robur 'Fastigiata',45,15,Yellow-Brown,Moderate,Columnar form. English Oak not explicit on approved list.,No (Private Property Only)
Valley Nursery,Ornamental/Shade,Oak,Gambel (Clump),Quercus gambelii,25,25,Yellow/Orange-Red,Low (Xeric),Native scrub oak; thrives in rocky soil. Prune for single stem in ROW.,Yes
Valley Nursery,Ornamental/Shade,Pear (Ornamental),Autumn Blaze,Pyrus calleryana 'Autumn Blaze',35,20,Red,Moderate,Early spring white blooms. Cold hardy.,Yes
Valley Nursery,Ornamental/Shade,Pear (Ornamental),Redspire,Pyrus calleryana 'Redspire',35,25,Yellow to Red,Moderate,Symmetrical form. Dwarf cultivar.,Yes
Valley Nursery,Ornamental/Shade,Pear (Ornamental),Aristocrat,Pyrus calleryana 'Aristocrat',40,28,Deep Red,Moderate,Broader structure. Tolerant of urban conditions.,Yes
Valley Nursery,Ornamental/Shade,Pear (Ornamental),Cleveland Select,Pyrus calleryana 'Cleveland Select',30,15,Reddish,Moderate,Narrow form. Dwarf cultivar.,Yes
Valley Nursery,Ornamental/Shade,Plum (Ornamental),Newport,Prunus cerasifera 'Newport',20,15,Reddish,Moderate,Purple foliage. Not explicit on approved list.,No (Private Property Only)
Valley Nursery,Ornamental/Shade,Plum (Ornamental),Thundercloud,Prunus cerasifera 'Thundercloud',20,15,Dark Purple,Moderate,Deepest purple foliage. Not explicit on approved list.,No (Private Property Only)
Valley Nursery,Ornamental/Shade,Zelkova,Musashino,Zelkova serrata 'Musashino',60,35,Yellow,Low-Med,Vase shape. Not explicit on approved list.,No (Private Property Only)
Valley Nursery,Ornamental/Shade,Zelkova,Green Vase,Zelkova serrata 'Green Vase',60,35,Orange,Low-Med,Faster growing. Not explicit on approved list.,No (Private Property Only)
Valley Nursery,Ornamental/Shade,Elm (Hybrid),Accolade,Ulmus japonica x wilsoniana,70,40,Yellow,Moderate,DED resistant. Hybrids generally approved but check specific cultivars.,Yes (Verify)
Valley Nursery,Ornamental/Shade,Elm (Hybrid),Frontier,Ulmus carpinifolia x parvifolia,40,30,Burgundy,Low-Med,Smaller elm; unique red fall color. Hybrids generally approved but check specific cultivars.,Yes (Verify)
Valley Nursery,Ornamental/Shade,Elm (Hybrid),Princeton,Ulmus americana 'Princeton',60,40,Yellow,Moderate,Native American Elm cultivar. Hybrids generally approved but check specific cultivars.,Yes (Verify)
Valley Nursery,Ornamental/Shade,Aspen,Quaking Aspen (Clump),Populus tremuloides,60,30,Gold,High,Native. PROHIBITED in ROW per GJ Forestry Board (Populus species).,No (Prohibited)
Valley Nursery,Ornamental/Shade,Cottonwood,Narrowleaf,Populus angustifolia,60,40,Yellow,High,Native. PROHIBITED in ROW per GJ Forestry Board (Populus species).,No (Prohibited)
Valley Nursery,Ornamental/Shade,Cottonwood,Lanceleaf,Populus x acuminata,45,25,Yellow,High,Native. PROHIBITED in ROW per GJ Forestry Board (Populus species).,No (Prohibited)
Valley Nursery,Ornamental/Shade,Cottonwood,Fremont,Populus fremontii,50,50,Yellow,High,Native. PROHIBITED in ROW per GJ Forestry Board (Populus species).,No (Prohibited)
Valley Nursery,Evergreen,Pine,Austrian,Pinus nigra,60,40,N/A,Low-Med,Tolerates clay/salt. Conifers NOT approved for ROW (growth habit conflicts).,No (Private Property Only)
Valley Nursery,Evergreen,Spruce,Colorado Blue,Picea pungens,60,25,N/A,Moderate,Native. Conifers NOT approved for ROW (growth habit conflicts).,No (Private Property Only)
Valley Nursery,Evergreen,Pine,Pinon,Pinus edulis,20,20,N/A,Very Low (Xeric),Native. Conifers NOT approved for ROW (growth habit conflicts).,No (Private Property Only)
Valley Nursery,Clump Form,Chokecherry,Clump,Prunus virginiana,20,15,Red,Low-Med,Multi-stem form. Approved (Non-suckering varieties).,Yes
Valley Nursery,Clump Form,Birch,River Birch Clump,Betula nigra,30,20,Yellow,Moist,Peeling bark. Not explicit on approved list.,No (Private Property Only)
Valley Nursery,Clump Form,Lilac,Lilac Clump,Syringa vulgaris,12,10,N/A,Moderate,Old fashioned fragrance. Not explicit on approved list.,No (Private Property Only)
Valley Nursery,Clump Form,Serviceberry,Autumn Brilliance,Amelanchier x grandiflora,20,15,Red-Orange,Moderate,Edible fruit. Approved (Single stem preferred for ROW).,Yes
Valley Nursery,Clump Form,Maple,Ginnala (Amur),Acer ginnala,18,15,Red-Orange,Low-Med,Hardy. Not explicit on approved list.,No (Private Property Only)
Valley Nursery,Clump Form,Oak,Gambel Clump,Quercus gambelii,20,20,Yellow-Red,Very Low,Multi-stem native. Approved (Prune for clearance).,Yes
Valley Nursery,Clump Form,Sandcherry,Purple Leaf,Prunus x cistena,8,8,Purple,Moderate,Rich purple foliage. Not explicit on approved list.,No (Private Property Only)
Valley Nursery,Fruit,Apple,Honeycrisp,Malus domestica 'Honeycrisp',15,15,N/A,Moderate,Heavy crop. Fruit trees restricted in ROW.,No (Private Property Only)
Valley Nursery,Fruit,Peach,Elberta,Prunus persica 'Elberta',15,15,N/A,Moderate,Self-pollinating. Fruit trees restricted in ROW.,No (Private Property Only)
Valley Nursery,Fruit,Peach,Red Haven,Prunus persica 'Red Haven',15,15,N/A,Moderate,Self-pollinating. Fruit trees restricted in ROW.,No (Private Property Only)
Valley Nursery,Fruit,Cherry,Bing,Prunus avium 'Bing',35,25,N/A,Moderate,Sweet cherry. Fruit trees restricted in ROW.,No (Private Property Only)
Valley Nursery,Fruit,Cherry,Montmorency,Prunus cerasus 'Montmorency',25,12,N/A,Moderate,Pie/Tart cherry. Fruit trees restricted in ROW.,No (Private Property Only)
Chelsea Nursery,Ornamental/Shade,Maple,Autumn Blaze,Acer x freemanii 'Jeffersred',45,35,Red,Medium,Fast growing hybrid. PROHIBITED in ROW per GJ Forestry Board (Freeman Maple).,No (Prohibited)
Chelsea Nursery,Ornamental/Shade,Maple,Bigtooth,Acer grandidentatum,35,22,Yellow to Red,Low,Native Rocky Mtn; slow growing. Approved; alkaline tolerant.,Yes
Chelsea Nursery,Ornamental/Shade,Maple,Tatarian,Acer tataricum,20,18,Yellow/Maroon,Low,Single or multi-stem. Approved; rarely suckers.,Yes
Chelsea Nursery,Ornamental/Shade,Maple,Shantung,Acer truncatum,25,25,Yellow,Low,Small rounded tree. Approved.,Yes
Chelsea Nursery,Clump Form,Birch,River,Betula fontinalis,25,20,Yellow,Moist,Native riparian. Not explicit on approved list.,No (Private Property Only)
Chelsea Nursery,Ornamental/Shade,Catalpa,Umbrella,Catalpa bungei,25,20,Yellow,Low,Round headed. Not explicit on approved list.,No (Private Property Only)
Chelsea Nursery,Ornamental/Shade,Catalpa,Northern/Western,Catalpa speciosa,55,35,Yellow,Low,Fast growing; drought tolerant. Approved; decay issues with age.,Yes
Chelsea Nursery,Ornamental/Shade,Hackberry,Common,Celtis occidentalis,50,50,Yellow,Low,Native; corky bark. Approved.,Yes
Chelsea Nursery,Ornamental/Shade,Redbud,Eastern,Cercis canadensis,25,22,Yellow,Low-Med,Lavender flowers. Approved; plant in protected area.,Yes
Chelsea Nursery,Ornamental/Shade,Redbud,Forest Pansy,Cercis canadensis 'Forest Pansy',22,22,Yellow/Orange,Low-Med,Glossy red leaves. Approved; plant in protected area.,Yes
Chelsea Nursery,Ornamental/Shade,Hawthorn,Russian,Crataegus ambigua,20,18,N/A,Low,Irregular branches. Approved; drought tolerant.,Yes
Chelsea Nursery,Ornamental/Shade,Hawthorn,Cockspur Crusader,Crataegus crus-galli inermis 'Cruszam',18,22,Orange/Red,Low,Thornless. Approved; fruit litter potential.,Yes
Chelsea Nursery,Ornamental/Shade,Hawthorn,Crimson Cloud,Crataegus laevigata 'Crimson Cloud',18,18,Yellow,Low,Disease resistant. Approved; more disease resistant.,Yes
Chelsea Nursery,Ornamental/Shade,Hawthorn,Winter King,Crataegus viridis 'Winter King',18,18,Yellow,Low,Smooth gray bark. Approved.,Yes
Chelsea Nursery,Ornamental/Shade,Ginkgo,Maidenhair,Ginkgo biloba,55,45,Golden Yellow,Low,Ancient tree. Approved (Male clones only).,Yes
Chelsea Nursery,Ornamental/Shade,Honeylocust,Imperial,Gleditsia triacanthos 'Impcole',32,32,Yellow,Low,Compact; seedless. Approved.,Yes
Chelsea Nursery,Ornamental/Shade,Honeylocust,Shademaster,Gleditsia triacanthos 'Shademaster',45,32,Gold,Low,Graceful; seedless. Approved.,Yes
Chelsea Nursery,Ornamental/Shade,Honeylocust,Skyline,Gleditsia triacanthos 'Skycole',45,40,Gold,Low,Stately; uniform. Approved.,Yes
Chelsea Nursery,Evergreen,Juniper,Utah,Juniperus osteosperma,25,12,N/A,Very Low,Native. Conifers NOT approved for ROW.,No (Private Property Only)
Chelsea Nursery,Evergreen,Juniper,Rocky Mtn.,Juniperus scopulorum,25,10,N/A,Low,Native. Conifers NOT approved for ROW.,No (Private Property Only)
Chelsea Nursery,Ornamental/Shade,Golden Raintree,Standard,Koelreuteria paniculata,32,28,Yellow,Low,Yellow flowers. Approved.,Yes
Chelsea Nursery,Ornamental/Shade,Tuliptree,Standard,Liriodendron tulipifera,45,35,Yellow,Medium,Square leaves. Approved; requires large tree lawn.,Yes
Chelsea Nursery,Ornamental/Shade,Mulberry,Chaparral Weeping,Morus alba pendula 'Chaparral',18,15,Yellow,Low,Fruitless. Weeping trees PROHIBITED in ROW.,No (Prohibited)
Chelsea Nursery,Evergreen,Pine,Pinyon,Pinus edulis,25,15,N/A,Very Low,Native. Conifers NOT approved for ROW.,No (Private Property Only)
Chelsea Nursery,Ornamental/Shade,Wafer Ash,Standard,Ptelea trifoliata,12,13,Rust,Very Low,Native; small multi-stem. Approved (Common Hoptree).,Yes
Chelsea Nursery,Ornamental/Shade,Mountain Ash,Native,Sorbus scopulina,12,11,Yellow to Red,Medium,Native. Not explicit on approved list.,No (Private Property Only)
Unknown,Ornamental/Shade,Trident Maple,Streetwise,Acer buergeranum 'Streetwise',30,30,Orange-Red,Low,Slow growing. No pests/disease problems. Snow/ice damage concern.,Yes
Unknown,Ornamental/Shade,Hedge Maple,Standard,Acer campestre,30,30,Yellow,Low,Tolerates dry soil. Intolerant of soil compaction. Prune for clearance.,Yes
Unknown,Ornamental/Shade,Hedge Maple,Metro Gold,Acer campestre 'Panacek',30,15,Yellow,Low,Upright narrow form. Tolerates dry soil. Intolerant of compaction.,Yes
Unknown,Ornamental/Shade,Hedge Maple,Streetside,Acer campestre 'JFS-Schichtel2',32,15,Yellow,Low,Upright narrow form. Availability limited.,Yes
Unknown,Ornamental/Shade,Rocky Mountain Maple,Standard,Acer glabrum,20,13,Yellow-Orange-Red,Low,Plant in protected area (heat/tolerance concern).,Yes
Unknown,Ornamental/Shade,Bigtooth Maple,Rocky Mountain Glow,Acer grandidentatum 'Schmidt',20,13,Yellow-Orange-Red,Very Low,Faster growing than species. Intolerant of compaction.,Yes
Unknown,Ornamental/Shade,Bigtooth Maple,Mesa Glow,Acer grandidentatum 'JFS-NuMex 3',25,15,Orange-Red to Red,Very Low,Upright form. Slow growing. Alkaline tolerant.,Yes
Unknown,Ornamental/Shade,Maple,Highland Park,Acer grandidentatum x saccharum 'Hipzam',35,22,Red,Low,Faster growing/more upright than Bigtooth. Heat/drought resistant.,Yes
Unknown,Ornamental/Shade,Maple,Canyon Treasure,Acer grandidentatum x saccharum 'Orbit',35,22,Red,Low,Very cold hardy. Availability limited.,Yes
Unknown,Ornamental/Shade,Paperbark Maple,Standard,Acer griseum,25,20,Yellow-Orange-Red,Moderate,Very slow growing. Exfoliating bark. Intolerant of extended drought.,Yes
Unknown,Ornamental/Shade,Paperbark Maple,Fireburst,Acer griseum 'JFS-KW8AGRI',22,15,Brilliant Red,Moderate,Faster growing than parent. Exfoliating bark. Improved branch structure.,Yes
Unknown,Ornamental/Shade,Miyabe Maple,State Street,Acer miyabei 'Morton',45,35,Yellow-Orange,Moderate,Cold hardy & drought tolerant. Chlorosis resistant.,Yes
Unknown,Ornamental/Shade,Miyabe Maple,Rugged Ridge,Acer miyabei 'JFS-KW3AMI',50,35,Yellow,Moderate,Cold hardy & drought tolerant. Touted as most vigorous Miyabe.,Yes
Unknown,Ornamental/Shade,Black Maple,Standard,Acer nigrum,60,40,Yellow-Orange-Red,Moderate,More drought/heat tolerant than Sugar Maple. Intolerant poorly drained soil.,Yes
Unknown,Ornamental/Shade,Black Maple,Greencolumn,Acer nigrum 'Greencolumn',45,15,Yellow-Orange,Low-Mod,Good heat/drought tolerance. Narrow upright.,Yes
Unknown,Ornamental/Shade,Sycamore Maple,Standard,Acer pseudoplatanus,45,25,Green,Moderate,Soil adaptable and salt tolerant. Intolerant of heavy clay.,Yes
Unknown,Ornamental/Shade,Korean Maple,Northern Spotlight,Acer pseudosieboldianum 'KorDek',15,15,Orange-Deep-Red,Moderate,Cold hardy. Leaves resistant to scorch. Thin bark.,Yes
Unknown,Ornamental/Shade,Korean Maple,Northern Glow,Acer pseudosieboldianum x palmatum 'Hasselkus',15,15,Orange-Deep-Red,Moderate,Cold hardy. Leaves resistant to scorch. Thin bark.,Yes
Unknown,Ornamental/Shade,Red Maple,Fall Grandeur,Acer rubrum 'Pollett',40,30,Red,Low-Mod,Alkaline soil tolerant variety. (Check if allowed - Freeman prohibited).,Yes
Unknown,Ornamental/Shade,Sugar Maple,John Pair Caddo,Acer saccharum 'John Pair',27,27,Red,Low-Mod,Heat drought and alkaline soil tolerant cultivar.,Yes
Unknown,Ornamental/Shade,Sugar Maple,Autumn Splendor Caddo,Acer saccharum 'Autumn Splendor',40,35,Orange-Red,Low-Mod,Heat drought and alkaline soil tolerant cultivar.,Yes
Unknown,Ornamental/Shade,Sugar Maple,Flashfire Caddo,Acer saccharum 'JFS-Caddo2',40,35,Bright Red,Low-Mod,Heat drought and alkaline soil tolerant. Best early fall color.,Yes
Unknown,Ornamental/Shade,Tatarian Maple,Rugged Charm,Acer tataricum 'JFS-KW2',24,15,Yellow-Orange-Red,Very Low,Compact oval. Rarely suckers. Showy seed crop.,Yes
Unknown,Ornamental/Shade,Tatarian Maple,Pattern Perfect,Acer tataricum 'Patdell',21,10,Yellow-Orange-Red,Low,Oval form narrower than species. Rarely suckers.,Yes
Unknown,Ornamental/Shade,Three Flower Maple,Standard,Acer triflorum,15,15,Bright Orange,Moderate,Slow growing. Intolerant of drought/alkaline soil. Unproven in Grand Valley.,Yes
Unknown,Ornamental/Shade,Shantung Hybrid,Ruby Sunset,Acer truncatum x platanoides 'JFS-KW249',22,17,Deep Red,Low,Availability limited. Unproven in Grand Valley.,Yes
Unknown,Ornamental/Shade,Shantung Hybrid,Urban Sunset,Acer truncatum x platanoides 'JFS-KW187',35,20,Red,Low,Narrow pyramidal. Minimal pruning required.,Yes
Unknown,Ornamental/Shade,Shantung Hybrid,Crimson Sunset,Acer truncatum x platanoides 'JFS-KW202',30,20,Reddish-Bronze,Low,More heat/drought tolerant than parent. Thin bark.,Yes
Unknown,Ornamental/Shade,Yellow Buckeye,Standard,Aesculus flava,60,30,Pumpkin,Moderate,Greater leaf blotch resistance than other Aesculus.,Yes
Unknown,Ornamental/Shade,Ohio Buckeye,Standard,Aesculus glabra,35,35,Pumpkin-Yellow,Moderate,Intolerant of excess heat/drought. Prune for clearance.,Yes
Unknown,Ornamental/Shade,Horsechestnut,Baumannii,Aesculus hippocastanum 'Baumannii',45,36,Yellow,Moderate,Double white flowers. Fruitless. Intolerant of excess heat/drought.,Yes
Unknown,Ornamental/Shade,Buckeye,Autumn Splendor,Aesculus x arnoldiana 'Autumn Splendor',30,25,Red-Orange-Purple,Moderate,Resistant to leaf scorch. Intolerant of drought.,Yes
Unknown,Ornamental/Shade,Buckeye,Prairie Torch,Aesculus x bushii 'Bergeson',27,27,Orange-Red,Moderate,Excellent cold hardiness. Resistant to leaf scorch.,Yes
Unknown,Ornamental/Shade,Horsechestnut,Ft McNair,Aesculus x carnea 'Ft McNair',29,27,Yellow,Moderate,Pink flowers. More leaf blotch resistant than parent.,Yes
Unknown,Ornamental/Shade,Horsechestnut,Briotii,Aesculus x carnea 'Briotii',27,32,Yellow,Moderate,Bright red flowers. Nearly fruitless. Intolerant of drought.,Yes
Unknown,Ornamental/Shade,Buckeye,Homestead,Aesculus 'Homestead',35,22,Bright Red-Orange,Moderate,Intolerant of excess heat/drought. Prune for clearance.,Yes
Unknown,Ornamental/Shade,Serviceberry,Downy,Amelanchier arborea,20,15,Orange-Red-Yellow,Low-Mod,Intolerant of pollution. Thin bark.,Yes
Unknown,Ornamental/Shade,Serviceberry,Shadblow,Amelanchier canadensis,20,15,Orange-Red-Yellow,Low-Mod,Thin bark. Prune to develop single stem form.,Yes
Unknown,Ornamental/Shade,Serviceberry,Allegheny,Amelanchier laevis,22,15,Red-Orange-Yellow,Low-Mod,Tolerant of full shade. Good selection for single stem form.,Yes
Unknown,Ornamental/Shade,Serviceberry,Spring Flurry,Amelanchier laevis 'JFS-Arb',25,15,Red-Orange-Yellow,Low-Mod,Tolerant of full shade. Dominant central leader. Good for single stem.,Yes
Unknown,Ornamental/Shade,Pawpaw,Standard,Asimina triloba,21,12,Yellow,Moderate,Tolerant of full shade. Plant where fruit not problematic. Unproven in GV.,Yes
Unknown,Ornamental/Shade,Hornbeam,Columnar European,Carpinus betulus 'Frans Fontaine',35,20,Yellow,Moderate,Intolerant of excess/reflective heat. Plant in protected sites.,Yes
Unknown,Ornamental/Shade,Hornbeam,American,Carpinus caroliniana,25,32,Orange-Red-Yellow,Moderate,Tolerant of periodic flooding. Intolerant of compaction.,Yes
Unknown,Ornamental/Shade,Hornbeam,Rising Fire,Carpinus caroliniana 'Uxbridge',22,12,Red-Orange,Moderate,Columnar form. Tolerant of periodic flooding. Intolerant compaction.,Yes
Unknown,Ornamental/Shade,Hickory,Pignut,Carya glabra,50,30,Yellow-Copper,Low-Mod,Difficult to transplant (taproot). Unproven in Grand Valley.,Yes
Unknown,Ornamental/Shade,Pecan,Standard,Carya illinoinensis,60,40,Yellow,Moderate,Northern seed source critical. Large root system requires large tree lawn.,Yes
Unknown,Ornamental/Shade,Hickory,Shagbark,Carya ovata,50,30,Burnt Yellow,Moderate,Difficult to transplant. Unproven in Grand Valley.,Yes
Unknown,Ornamental/Shade,Catalpa,Chinese,Catalpa ovata,30,25,Yellow,Low,Smaller than Western Catalpa. Heat/drought/alkaline tolerant.,Yes
Unknown,Ornamental/Shade,Catalpa,Heartland,Catalpa speciosa 'Hiawatha 2',45,23,Yellow,Low,Narrow upright form. Uniform branching.,Yes
Unknown,Ornamental/Shade,Catalpa,Purple,Catalpa x erubescens 'Purpurea',40,35,Yellow,Low,Purple leaved cultivar. Intermediate drought tolerance.,Yes
Unknown,Ornamental/Shade,Hackberry,Sugar,Celtis laevigata,45,40,Yellow,Low,Similar growth to elm & improved insect resistance.,Yes
Unknown,Ornamental/Shade,Hackberry,Prairie Sentinel,Celtis occidentalis 'JFS-KS1',45,12,Yellow,Low,Columnar cultivar. Tolerant of confined spaces.,Yes
Unknown,Ornamental/Shade,Hackberry,Netleaf,Celtis reticulata,25,25,Yellow,Low,Slow growing. Also known as Western Hackberry.,Yes
Unknown,Ornamental/Shade,Katsuratree,Standard,Cercidiphyllum japonicum,35,35,Yellow-Orange,Moderate,Intolerant of soil compaction. Shallow surface roots.,Yes
Unknown,Ornamental/Shade,Redbud,Northern Herald,Cercis canadensis 'Pink Trim',22,28,Yellow,Low-Mod,Cold hardy variety. Tolerant of urban conditions.,Yes
Unknown,Ornamental/Shade,Redbud,Rising Sun,Cercis canadensis 'JN2',20,18,Yellow w/Orange,Low-Mod,Yellow with orange new growth. Plant in protected area.,Yes
Unknown,Ornamental/Shade,Desert Willow,Standard,Chilopsis linearis,20,20,Yellow,Very Low,Exotic looking blooms. Rapid growth. Drought tolerance.,Yes
Unknown,Ornamental/Shade,Fringetree,Chinese,Chionanthus retusus,15,15,Yellow,Moderate,Slow growing. Intolerant of drought. Not affected by EAB.,Yes
Unknown,Ornamental/Shade,Fringetree,Tokyo Tower,Chionanthus retusus 'Tokyo Tower',15,6,Yellow,Moderate,Narrow upright vase. Tolerant confined spaces. Intolerant drought.,Yes
Unknown,Ornamental/Shade,Fringetree,American,Chionanthus virginicus,15,15,Yellow,Low-Mod,Slow growing. Susceptible to Emerald Ash Borer.,Yes
Unknown,Ornamental/Shade,Yellowwood,Standard,Cladrastis kentukea,35,35,Yellow,Moderate,Flowers source of nectar. Thin smooth bark easily damaged.,Yes
Unknown,Ornamental/Shade,Yellowwood,Perkins Pink,Cladrastis kentukea 'Perkins Pink',40,45,Yellow,Moderate,Pink clusters in spring. Thin bark.,Yes
Unknown,Ornamental/Shade,Dogwood,June Snow,Cornus controversa 'June Snow',25,35,Orange-Red,Moderate,Horizontally layered. Unproven in Grand Valley.,Yes
Unknown,Ornamental/Shade,Dogwood,Corneliancherry,Cornus mas,15,12,Purple-Red,Moderate,Yellow flowers early spring. Highly resistant to storm damage.,Yes
Unknown,Ornamental/Shade,Filbert,Turkish,Corylus colurna,40,25,Yellow,Very Low,Plant in sites with large rooting space. Slow to establish.,Yes
Unknown,Ornamental/Shade,Smoketree,American,Cotinus obovatus,10,13,Orange-Red-Yellow,Low-Mod,Blooming flowers create smoke-like effect.,Yes
Unknown,Ornamental/Shade,Hawthorn,Northern Downy,Crataegus submollis,20,20,Yellow,Low-Mod,Thorns up to 3 inches. Unproven in Grand Valley.,Yes
Unknown,Ornamental/Shade,Hawthorn,Snowbird/Toba,Crataegus x mordenensis,20,20,N/A,Low,Drought tolerant. Fireblight may be an issue.,Yes
Unknown,Ornamental/Shade,Hardy Rubber Tree,Standard,Eucommia ulmoides,40,40,Yellow,Low,Prune to develop strong branching structure.,Yes
Unknown,Ornamental/Shade,Hardy Rubber Tree,Emerald Pointe,Eucommia ulmoides 'Empozam',35,15,Yellow,Low,Upright narrow. Availability limited.,Yes
Unknown,Ornamental/Shade,Beech,American,Fagus grandifolia,65,60,Golden Bronze,Moderate,Slow growing. Intolerant of wet/compacted soils. Thin bark.,Yes
Unknown,Ornamental/Shade,Beech,European,Fagus sylvatica,50,40,Golden Bronze,Moderate,Slow growing. More tolerant of varying soils than American.,Yes
Unknown,Ornamental/Shade,Beech,Copper,Fagus sylvatica 'Purpurea',50,40,Red-Orange,Moderate,Dark red foliage. Slow growing.,Yes
Unknown,Ornamental/Shade,Beech,Tricolor,Fagus sylvatica 'Roseomarginata',40,30,Light Bronze,Moderate,Variegated purple/rose/cream. Thin bark easily damaged.,Yes
Unknown,Ornamental/Shade,Ginkgo,Autumn Gold,Ginkgo biloba 'Autumn Gold',40,30,Golden Yellow,Moderate,Male (seedless) clone. Moderate growth rate.,Yes
Unknown,Ornamental/Shade,Ginkgo,Golden Colonnade,Ginkgo biloba 'JFS-UGA2',40,20,Golden Yellow,Moderate,Narrow oval. Male (seedless) clone.,Yes
Unknown,Ornamental/Shade,Ginkgo,Magyar,Ginkgo biloba 'Magyar',45,20,Golden Yellow,Moderate,Narrow to pyramidal. Male (seedless) clone.,Yes
Unknown,Ornamental/Shade,Ginkgo,Presidential Gold,Ginkgo biloba 'The President',45,35,Golden Yellow,Moderate,Broad pyramidal. Male (seedless) clone. Slow growth.,Yes
Unknown,Ornamental/Shade,Ginkgo,Princeton Sentry,Ginkgo biloba 'Princeton Sentry',40,15,Golden Yellow,Moderate,Narrow pyramidal. Male (seedless) clone.,Yes
Unknown,Ornamental/Shade,Ginkgo,Shangri-la,Ginkgo biloba 'Shangri-la',45,30,Golden Yellow,Moderate,Male clone. Slow grower.,Yes
Unknown,Ornamental/Shade,Honeylocust,Northern Acclaim,Gleditsia triacanthos 'Harve',40,30,Yellow,Very Low,Thornless/Fruitless. Genus overplanted.,Yes
Unknown,Ornamental/Shade,Honeylocust,Street Keeper,Gleditsia triacanthos 'Draves',40,15,Yellow,Very Low,Columnar. Thornless/Fruitless.,Yes
Unknown,Ornamental/Shade,Honeylocust,True Shade,Gleditsia triacanthos 'True Shade',40,30,Yellow,Very Low,Oval. Thornless/Fruitless.,Yes
Unknown,Ornamental/Shade,Coffeetree,Espresso,Gymnocladus dioicus 'Espresso',60,40,Yellow,Very Low,Male (fruitless). Tolerant of urban conditions.,Yes
Unknown,Ornamental/Shade,Coffeetree,Prairie Titan,Gymnocladus dioicus 'J.C. McDaniel',55,35,Yellow,Low,Male (fruitless). Upright spreading.,Yes
Unknown,Ornamental/Shade,Coffeetree,Stately Manor,Gymnocladus dioicus 'Stately Manor',45,20,Yellow,Low,Male (fruitless). Narrow upright.,Yes
Unknown,Ornamental/Shade,Goldenrain Tree,Summer Burst,Koelreuteria paniculata 'JFS-Sunleaf',30,30,Yellow,Very Low,More heat resistant than parent. Lantern pods.,Yes
Unknown,Ornamental/Shade,Sweetgum,Standard,Liquidambar styraciflua,60,40,Red-Orange-Yellow,Mod-High,Shallow surface roots. 'Rotundiloba' is seedless cultivar.,Yes
Unknown,Ornamental/Shade,Tulip Tree,Emerald City,Liriodendron tulipifera 'JFS-Oz',55,25,Yellow,Mod-High,Upright oval. Cold hardy. Unproven in Grand Valley.,Yes
Unknown,Ornamental/Shade,Maackia,Amur,Maackia amurensis,25,18,Yellow,Very Low,Tolerant of urban conditions/drought. White summer flowers.,Yes
Unknown,Ornamental/Shade,Maackia,MaacNificent,Maackia amurensis 'MaacNificent',28,20,Yellow,Very Low,Upright vase. Branching more upright than species.,Yes
Unknown,Ornamental/Shade,Maackia,Summertime,Maackia amurensis 'Summertime',20,16,Yellow,Very Low,Small cultivar. Low branching habit.,Yes
Unknown,Ornamental/Shade,Maackia,Starburst,Maackia amurensis 'Starburst',22,18,Yellow,Very Low,Low branching habit. White flowers.,Yes
Unknown,Ornamental/Shade,Osage Orange,White Shield,Maclura pomifera 'White Shield',30,30,Yellow,Very Low,Fruitless/Thornless male. Tolerant of heat/drought.,Yes
Unknown,Ornamental/Shade,Osage Orange,Wichita,Maclura pomifera 'Wichita',30,30,Yellow,Very Low,Fruitless/Thornless male. Tolerant of wet/dry soils.,Yes
Unknown,Ornamental/Shade,Magnolia,Mercury,Magnolia 'Mercury',21,12,Yellow,Moderate,Large lavender pink flowers. Late blooming. Unproven in GV.,Yes
Unknown,Ornamental/Shade,Magnolia,Cucumbertree,Magnolia acuminata,65,50,Yellow-Bronze,Moderate,Fast growing. Intolerant compacted soils. Large root system.,Yes
Unknown,Ornamental/Shade,Hophornbeam,Autumn Treasure,Ostrya virginiana 'JFS-KW5',35,17,Golden Yellow,Low-Mod,Upright narrow. Slow to establish. Unproven in GV.,Yes
Unknown,Ornamental/Shade,Parrotia,Persian,Parrotia persica,33,30,Orange-Red-Yellow,Low-Mod,Exfoliating bark. Few issues once established.,Yes
Unknown,Ornamental/Shade,Parrotia,Persian Spire,Parrotia persica 'JFS-PN1',25,10,Orange-Red-Yellow,Low-Mod,Columnar. New introduction.,Yes
Unknown,Ornamental/Shade,Parrotia,Vanessa,Parrotia persica 'Vanessa',30,19,Orange-Red-Yellow,Low-Mod,Upright vase. New introduction.,Yes
Unknown,Ornamental/Shade,Corktree,Amur,Phellodendron amurense,45,45,Yellow,Low-Mod,Use only male cultivars (fruit messy). Shallow root system.,Yes
Unknown,Ornamental/Shade,Corktree,His Majesty,Phellodendron amurense 'His Majesty',30,25,Yellow,Low-Mod,Broad vase. Generally fruitless (Male).,Yes
Unknown,Ornamental/Shade,Corktree,Eye Stopper,Phellodendron amurense 'Longenecker',30,25,Yellow,Low-Mod,Upright to rounded. Generally fruitless (Male).,Yes
Unknown,Ornamental/Shade,Corktree,Macho,Phellodendron amurense 'Macho',40,40,Yellow,Low-Mod,Upright to rounded. Fruitless (Male).,Yes
Unknown,Ornamental/Shade,Pistache,Chinese,Pistacia chinensis,35,20,Yellow-Orange,Low,Good heat/drought tolerance. Dioecious.,Yes
Unknown,Ornamental/Shade,Sycamore,American,Platanus occidentalis,75,60,Yellow,Moderate,Large root system. Fruit litter may be issue.,Yes
Unknown,Ornamental/Shade,Sycamore,Northern Advance,Platanus occidentalis 'Bismarck',75,60,Yellow,Moderate,Cold hardy cultivar.,Yes
Unknown,Ornamental/Shade,Sycamore,Texas,Platanus occidentalis 'Glabra',75,60,Yellow,Moderate,Alkaline soil tolerant. Fast growing. Anthracnose resistant.,Yes
Unknown,Ornamental/Shade,Planetree,Bloodgood,Platanus x acerifolia 'Bloodgood',40,35,Yellow,Moderate,Showy bark. Anthracnose resistant. Large root system.,Yes
Unknown,Ornamental/Shade,Planetree,Exclamation,Platanus x acerifolia 'Morton Circle',50,30,Yellow,Moderate,Showy bark. Anthracnose resistant.,Yes
Unknown,Ornamental/Shade,Chokecherry,Sucker Punch,Prunus x virginiana 'P002',20,18,Purple-Red,Low-Mod,Non-suckering cultivar. White flowers.,Yes
Unknown,Ornamental/Shade,Wingnut,Chinese,Pterocarya stenoptera,60,60,Yellow-Green,Low-Mod,Suckering/cold hardiness issues. Large root system. Unproven in GV.,Yes
Unknown,Ornamental/Shade,Pear,Korean Sun,Pyrus fauriei 'Westwood',10,12,Red-Purple,Low-Mod,Compact round. Fast growing dwarf.,Yes
Unknown,Ornamental/Shade,Pear,Mountain Frost,Pyrus ussuriensis 'Bailfrost',20,15,Yellow-Red,Low-Mod,Greatest cold hardiness. Fireblight resistant.,Yes
Unknown,Ornamental/Shade,Pear,Prairie Gem,Pyrus ussuriensis 'Mordak',20,15,Yellow,Low-Mod,Greatest cold hardiness. Fireblight resistant.,Yes
Unknown,Ornamental/Shade,Oak,Sawtooth,Quercus acutissima,50,50,Yellow-Brown,Low-Mod,Tolerant of heat/humidity. Chlorosis may be issue. Unproven in GV.,Yes
Unknown,Ornamental/Shade,Oak,White,Quercus alba,60,60,Red,Moderate,Slow growing. May be intolerant of alkaline soils.,Yes
Unknown,Ornamental/Shade,Oak,American Dream,Quercus bicolor 'JFS-KW12',50,50,Copper-Orange,Low-Mod,Tolerant of urban conditions/flooding/drought. Anthracnose resistant.,Yes
Unknown,Ornamental/Shade,Oak,Beacon,Quercus bicolor 'Bonnie and Mike',45,15,Yellow,Low-Mod,Narrow columnar. Tolerant of urban conditions.,Yes
Unknown,Ornamental/Shade,Oak,Texas Red,Quercus buckleyi,35,35,Red,Low-Mod,Native of Texas. Tolerant of alkaline soils/drought.,Yes
Unknown,Ornamental/Shade,Oak,Lacey,Quercus glaucoides,30,25,Yellow-Brown,Very Low,Native of Texas. Tolerant of heat/drought/alkaline. Unproven in GV.,Yes
Unknown,Ornamental/Shade,Oak,Shingle,Quercus imbricaria,50,50,Yellow-Red,Moderate,May be intolerant of alkaline soils. Large root system.,Yes
Unknown,Ornamental/Shade,Oak,Bullet Proof Bur,Quercus macrocarpa 'Bullet Proof',70,60,Copper-Yellow,Low-Med,High resistance to bullet gall. Large root system.,Yes
Unknown,Ornamental/Shade,Oak,Cobblestone,Quercus macrocarpa 'JFS-KW14',50,40,Yellow,Low-Med,Bark displays more cork-like features.,Yes
Unknown,Ornamental/Shade,Oak,Urban Pinnacle,Quercus macrocarpa 'JFS-KW3',50,20,Yellow,Low-Med,Narrow pyramidal. Strong central leader.,Yes
Unknown,Ornamental/Shade,Oak,Chinkapin,Quercus muehlenbergii,45,50,Yellow,Moderate,Tolerant of alkaline soils. Prune to develop central leader.,Yes
Unknown,Ornamental/Shade,Oak,Red Autumn Chinkapin,Quercus muehlenbergii 'Red Autumn',45,50,Red,Moderate,Variety displays better fall color than species.,Yes`;

const parseRange = (val: string): [number, number] => {
  if (!val || val.trim() === '') return [0, 0];
  const trimmed = val.trim();
  if (trimmed.includes('-')) {
    const parts = trimmed.split('-').map(p => parseFloat(p.trim()));
    return [parts[0] || 0, parts[1] || 0];
  }
  const n = parseFloat(trimmed);
  return [n || 0, n || 0];
};

export const trees: Tree[] = rawData.split('\n').map((line, idx) => {
  const parts = line.split(',');
  const nursery = parts[0];
  const category = parts[1];
  const commonName = parts[2];
  const variety = parts[3];
  const scientificName = parts[4];
  const height = parts[5];
  const width = parts[6];
  const fallColor = parts[7];
  const waterNeeds = parts[8];
  const notes = parts[9];
  const publicApproved = parts[10];

  const [hMin, hMax] = parseRange(height);
  const [wMin, wMax] = parseRange(width);

  // Derive intelligence
  const notesLower = notes ? notes.toLowerCase() : '';
  const isNative = notesLower.includes('native') || commonName.toLowerCase().includes('native');
  const isFruitCategory = category === 'Fruit';
  const hasFruit = notesLower.includes('fruit') || isFruitCategory || notesLower.includes('edible') || notesLower.includes('samara');
  const hasFlowers = notesLower.includes('flower') || notesLower.includes('bloom') || notesLower.includes('panicle') || notesLower.includes('cluster');
  
  let sunReq: 'Full Sun' | 'Partial' | 'Shade' = 'Full Sun';
  if (notesLower.includes('full shade') || notesLower.includes('tolerant of full shade')) sunReq = 'Shade';
  else if (notesLower.includes('protected') || notesLower.includes('partial shade') || notesLower.includes('protected area')) sunReq = 'Partial';

  const soilPref = [];
  if (notesLower.includes('alkaline')) soilPref.push('Alkaline');
  if (notesLower.includes('clay')) soilPref.push('Clay');
  if (notesLower.includes('urban') || notesLower.includes('pollution') || notesLower.includes('compacted') || notesLower.includes('compaction')) soilPref.push('Compacted');

  // Phenology Logic based on Colorado's climate (Zones 5-7)
  const phenology: MonthData[] = Array.from({ length: 12 }, (_, i) => {
    const month = i + 1;
    let status: MonthStatus = 'dormant';
    let isFlowering = false;
    let isFruiting = false;

    if (category === 'Evergreen') {
      status = 'foliage';
    } else {
      // Standard Deciduous Lifecycle (CO)
      if (month === 4) status = 'budding';
      else if (month >= 5 && month <= 8) status = 'foliage';
      else if (month >= 9 && month <= 10) status = 'fall-color';
      else status = 'dormant';
    }

    // Specific Flowering Windows
    if (hasFlowers) {
      if ((commonName.includes('Lilac') || commonName.includes('Redbud')) && month === 5) isFlowering = true;
      else if ((commonName.includes('Crabapple') || commonName.includes('Pear')) && month === 4) isFlowering = true;
      else if (commonName.includes('Goldenrain') && month === 7) isFlowering = true;
      else if (commonName.includes('Catalpa') && month === 6) isFlowering = true;
      else if (month === 4 || month === 5) isFlowering = true; // Default spring bloom
    }

    // Specific Fruiting Windows
    if (hasFruit) {
      if (commonName.includes('Apple') && month >= 9 && month <= 10) isFruiting = true;
      else if (commonName.includes('Peach') && month === 8) isFruiting = true;
      else if (commonName.includes('Cherry') && month === 6) isFruiting = true;
      else if (commonName.includes('Hawthorn') && month >= 9 && month <= 11) isFruiting = true;
      else if (month >= 8 && month <= 10) isFruiting = true; // Default fall fruit
    }

    return { status, isFlowering, isFruiting };
  });

  return {
    id: `tree-${idx}`,
    nursery: nursery || 'Unknown',
    category: category || 'Miscellaneous',
    commonName: commonName || 'Unnamed Tree',
    variety: variety || 'Standard',
    scientificName: scientificName || 'N/A',
    heightMin: hMin,
    heightMax: hMax,
    widthMin: wMin,
    widthMax: wMax,
    fallColor: fallColor || 'N/A',
    waterNeeds: waterNeeds || 'Moderate',
    notes: notes || '',
    publicApproved: publicApproved || 'No',
    isNative,
    hasFruit,
    hasFlowers,
    sunRequirement: sunReq,
    soilPref,
    phenology
  };
});