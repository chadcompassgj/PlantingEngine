
import React from 'react';
import { Tree, ProjectItem } from '../types';
import { Droplets, Ruler, ShieldCheck, AlertTriangle, FileText, Heart, Leaf, Sun } from 'lucide-react';
import SeasonalGraph from './SeasonalGraph';

interface TreeGridProps {
  trees: Tree[];
  viewMode: 'grid' | 'list';
  activeProjectItems: ProjectItem[];
  onToggleProject: (id: string) => void;
}

const TreeGrid: React.FC<TreeGridProps> = ({ trees, viewMode, activeProjectItems, onToggleProject }) => {
  if (trees.length === 0) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-slate-400 p-8 text-center">
        <div className="bg-slate-100 p-6 rounded-full mb-4">
          <AlertTriangle className="w-12 h-12 text-slate-300" />
        </div>
        <h3 className="text-lg font-bold text-slate-600">No Trees Found</h3>
        <p className="max-w-xs mt-2 font-medium">Refine your intelligent search.</p>
      </div>
    );
  }

  return (
    <div className={viewMode === 'grid' 
      ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-6" 
      : "flex flex-col gap-4"
    }>
      {trees.map((tree) => {
        const isInProject = activeProjectItems.some(i => i.treeId === tree.id);
        
        return (
          <div 
            key={tree.id}
            className={`bg-white rounded-2xl border border-slate-200 hover:border-emerald-500 transition-all duration-300 group relative ${viewMode === 'grid' ? 'shadow-sm hover:shadow-xl' : 'flex flex-col sm:flex-row shadow-sm hover:shadow-md'}`}
          >
            {/* Quick Project Toggle */}
            <button 
              onClick={() => onToggleProject(tree.id)}
              className={`absolute top-4 right-4 z-10 p-2 rounded-xl shadow-md transition-all ${isInProject ? 'bg-emerald-600 text-white' : 'bg-white text-slate-400 hover:text-emerald-600'}`}
            >
              <Heart className={`w-4 h-4 ${isInProject ? 'fill-current' : ''}`} />
            </button>

            {/* Header Info */}
            <div className={`p-5 ${viewMode === 'list' ? 'flex-1' : ''}`}>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-full tracking-wider bg-slate-100 text-slate-600">
                  {tree.category}
                </span>
                {tree.isNative && (
                  <span className="flex items-center gap-1 text-[9px] font-black uppercase px-2 py-0.5 rounded-full tracking-wider bg-emerald-100 text-emerald-800">
                    <Leaf className="w-2.5 h-2.5" /> Native
                  </span>
                )}
              </div>

              <h3 className="text-lg font-extrabold text-slate-900 leading-tight">
                {tree.commonName}
              </h3>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-tight mt-0.5">{tree.variety}</p>
              
              <div className="mt-4 flex items-center gap-3">
                <div className="flex items-center gap-1 text-xs font-bold text-slate-600">
                  <Sun className="w-3.5 h-3.5 text-amber-500" />
                  {tree.sunRequirement}
                </div>
                {tree.soilPref.length > 0 && (
                  <div className="text-[10px] text-slate-400 italic font-medium truncate">
                    Tolerates {tree.soilPref.join(', ')}
                  </div>
                )}
              </div>

              {/* Quick Stats Grid */}
              <div className="grid grid-cols-2 gap-3 mt-5 border-t border-slate-50 pt-4">
                <div className="flex flex-col">
                  <span className="text-[10px] font-black text-slate-300 uppercase flex items-center gap-1">
                    <Ruler className="w-3 h-3" /> Size
                  </span>
                  <span className="text-sm font-black text-slate-700">{tree.heightMax}' x {tree.widthMax}'</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[10px] font-black text-slate-300 uppercase flex items-center gap-1">
                    <Droplets className="w-3 h-3" /> Water
                  </span>
                  <span className="text-sm font-black text-slate-700">{tree.waterNeeds}</span>
                </div>
              </div>
            </div>

            {/* Phenology and Notes */}
            <div className={`p-5 bg-slate-50 border-t border-slate-100 rounded-b-2xl ${viewMode === 'list' ? 'flex-[1.5] border-t-0 border-l sm:border-l-slate-200 rounded-b-none sm:rounded-r-2xl flex flex-col gap-4' : 'flex flex-col gap-4'}`}>
              <SeasonalGraph tree={tree} compact={viewMode === 'grid'} />
              
              <div>
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-1">
                  <FileText className="w-3 h-3" />
                  Arborist Intelligence
                </h4>
                <p className="text-sm text-slate-600 font-medium leading-relaxed italic">
                  "{tree.notes}"
                </p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default TreeGrid;
