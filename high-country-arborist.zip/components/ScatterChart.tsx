
import React, { useState } from 'react';
import { Tree } from '../types';
import { Maximize2, MoveRight, Info } from 'lucide-react';

interface ScatterChartProps {
  trees: Tree[];
}

const ScatterChart: React.FC<ScatterChartProps> = ({ trees }) => {
  const [hoveredTree, setHoveredTree] = useState<Tree | null>(null);

  const padding = 60;
  const width = 800;
  const height = 500;
  
  const maxH = 80;
  const maxW = 80;

  const getX = (val: number) => padding + (val / maxH) * (width - padding * 2);
  const getY = (val: number) => height - padding - (val / maxW) * (height - padding * 2);

  return (
    <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm overflow-hidden relative">
      <div className="flex justify-between items-start mb-8">
        <div>
          <h2 className="text-xl font-black text-slate-900">Analysis Suite</h2>
          <p className="text-sm font-medium text-slate-500">Mature Canopy Spread: Height vs Width Analysis</p>
        </div>
        <div className="flex gap-4">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-emerald-500 shadow-sm shadow-emerald-200"></div>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Selected Species</span>
          </div>
        </div>
      </div>

      <div className="relative">
        <svg 
          viewBox={`0 0 ${width} ${height}`} 
          className="w-full h-auto text-slate-300 font-bold"
          style={{ maxHeight: 'calc(100vh - 300px)' }}
        >
          {/* Grid Lines */}
          {[0, 20, 40, 60, 80].map(v => (
            <React.Fragment key={v}>
              <line x1={getX(v)} y1={padding} x2={getX(v)} y2={height - padding} stroke="currentColor" strokeWidth="0.5" strokeDasharray="4" />
              <line x1={padding} y1={getY(v)} x2={width - padding} y2={getY(v)} stroke="currentColor" strokeWidth="0.5" strokeDasharray="4" />
              <text x={getX(v)} y={height - padding + 20} className="text-[12px] fill-slate-400 text-center" textAnchor="middle">{v}'</text>
              <text x={padding - 20} y={getY(v) + 5} className="text-[12px] fill-slate-400" textAnchor="end">{v}'</text>
            </React.Fragment>
          ))}

          {/* Axis Labels */}
          <text x={width / 2} y={height - 10} className="text-[10px] font-black fill-slate-900 uppercase tracking-widest" textAnchor="middle">Mature Height (ft)</text>
          <text x={15} y={height / 2} className="text-[10px] font-black fill-slate-900 uppercase tracking-widest" transform={`rotate(-90, 15, ${height / 2})`} textAnchor="middle">Mature Width (ft)</text>

          {/* Data Points */}
          {trees.map((tree) => {
            const isHovered = hoveredTree?.id === tree.id;
            return (
              <circle
                key={tree.id}
                cx={getX(tree.heightMax)}
                cy={getY(tree.widthMax)}
                r={isHovered ? 12 : 6}
                fill={tree.waterNeeds.includes('Low') ? '#10b981' : tree.waterNeeds.includes('High') ? '#3b82f6' : '#f59e0b'}
                className="cursor-pointer transition-all duration-300 hover:opacity-100 opacity-60"
                onMouseEnter={() => setHoveredTree(tree)}
                onMouseLeave={() => setHoveredTree(null)}
              />
            );
          })}
        </svg>

        {/* Tooltip Overlay */}
        {hoveredTree && (
          <div 
            className="absolute z-20 bg-slate-900 text-white p-4 rounded-2xl shadow-2xl w-64 pointer-events-none animate-in zoom-in-95 duration-200"
            style={{ 
              left: getX(hoveredTree.heightMax) / width * 100 + '%', 
              top: getY(hoveredTree.widthMax) / height * 100 + '%',
              transform: 'translate(-50%, -110%)'
            }}
          >
            <div className="flex justify-between items-start mb-2">
              <span className="text-[8px] font-black uppercase text-emerald-400">{hoveredTree.scientificName}</span>
              <span className="text-[8px] font-black uppercase">{hoveredTree.waterNeeds}</span>
            </div>
            <h4 className="font-extrabold text-sm mb-1">{hoveredTree.commonName}</h4>
            <div className="flex items-center gap-3 text-[10px] font-bold text-slate-400">
              <span className="flex items-center gap-1"><Maximize2 className="w-3 h-3" /> {hoveredTree.heightMax}' H</span>
              <span className="flex items-center gap-1"><MoveRight className="w-3 h-3" /> {hoveredTree.widthMax}' W</span>
            </div>
          </div>
        )}
      </div>

      <div className="mt-8 flex flex-wrap gap-6 border-t border-slate-50 pt-6">
        <div className="flex items-center gap-3">
          <Info className="w-4 h-4 text-slate-400" />
          <span className="text-xs font-bold text-slate-500 italic">Color Index: Green = Low Water, Blue = High Water, Orange = Moderate</span>
        </div>
      </div>
    </div>
  );
};

export default ScatterChart;
