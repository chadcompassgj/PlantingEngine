
import React from 'react';
import { Tree, MonthStatus } from '../types';
import { Flower, Apple } from 'lucide-react';

interface SeasonalGraphProps {
  tree: Tree;
  compact?: boolean;
}

const SeasonalGraph: React.FC<SeasonalGraphProps> = ({ tree, compact = false }) => {
  const months = ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'];

  const getStatusColor = (status: MonthStatus, fallColor: string) => {
    switch (status) {
      case 'budding': return 'bg-emerald-200';
      case 'foliage': return 'bg-emerald-600';
      case 'fall-color': 
        const color = fallColor.toLowerCase();
        if (color.includes('red')) return 'bg-red-500';
        if (color.includes('orange')) return 'bg-orange-500';
        if (color.includes('gold') || color.includes('yellow')) return 'bg-amber-400';
        if (color.includes('purple')) return 'bg-purple-600';
        return 'bg-amber-600';
      default: return 'bg-slate-100';
    }
  };

  return (
    <div className={`flex flex-col gap-1 ${compact ? 'w-full max-w-[200px]' : 'w-full'}`}>
      {!compact && (
        <div className="flex justify-between items-center mb-1">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Seasonal Lifecycle</span>
          <div className="flex gap-3">
             <div className="flex items-center gap-1"><div className="w-1.5 h-1.5 rounded-full bg-emerald-600"></div><span className="text-[8px] font-bold text-slate-400">Foliage</span></div>
             <div className="flex items-center gap-1"><Flower className="w-2 h-2 text-pink-400" /><span className="text-[8px] font-bold text-slate-400">Bloom</span></div>
             <div className="flex items-center gap-1"><Apple className="w-2 h-2 text-red-400" /><span className="text-[8px] font-bold text-slate-400">Fruit</span></div>
          </div>
        </div>
      )}
      <div className="grid grid-cols-12 gap-0.5 h-6">
        {tree.phenology.map((month, i) => (
          <div 
            key={i} 
            className={`relative group rounded-sm transition-all duration-300 ${getStatusColor(month.status, tree.fallColor)}`}
            title={`${months[i]}: ${month.status}`}
          >
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              {month.isFlowering && <Flower className="w-2.5 h-2.5 text-white/90" />}
              {month.isFruiting && <Apple className="w-2.5 h-2.5 text-white/90" />}
            </div>
            
            {/* Legend label for first/middle/last if not compact */}
            {!compact && (i % 3 === 0 || i === 11) && (
              <span className="absolute -top-4 left-0 text-[8px] font-black text-slate-300">{months[i]}</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default SeasonalGraph;
