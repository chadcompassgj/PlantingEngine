
import React from 'react';
import { FilterState, Project } from '../types';
import { Search, MapPin, X, Droplets, ShieldCheck, Ruler, Briefcase, Plus, Sparkles, Leaf, Apple } from 'lucide-react';

interface SidebarProps {
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  totalCount: number;
  projects: Project[];
  activeProjectId: string;
  setActiveProjectId: (id: string) => void;
  createProject: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  filters, setFilters, totalCount, projects, activeProjectId, setActiveProjectId, createProject 
}) => {
  const categories = ["Ornamental/Shade", "Evergreen", "Clump Form", "Fruit"];
  const nurseries = ["Valley Nursery", "Chelsea Nursery", "Unknown"];
  const waterLevels = ["Low (Xeric)", "Low", "Low-Med", "Moderate", "Medium", "High"];

  const toggleList = (list: string[], item: string) => {
    return list.includes(item) ? list.filter(i => i !== item) : [...list, item];
  };

  return (
    <aside className="w-full md:w-80 bg-white border-r border-slate-200 h-full overflow-y-auto scrollbar-hide flex flex-col z-40">
      {/* Projects Section */}
      <div className="p-4 border-b border-slate-100 bg-slate-50">
        <div className="flex justify-between items-center mb-4">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
            <Briefcase className="w-3 h-3" />
            Active Projects
          </label>
          <button onClick={createProject} className="p-1 hover:bg-slate-200 rounded-md text-emerald-600">
            <Plus className="w-4 h-4" />
          </button>
        </div>
        <div className="space-y-1 max-h-40 overflow-y-auto scrollbar-hide">
          {projects.map(p => (
            <button 
              key={p.id}
              onClick={() => setActiveProjectId(p.id)}
              className={`w-full text-left px-3 py-2 rounded-lg text-xs font-bold transition-all flex justify-between items-center ${activeProjectId === p.id ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-600 hover:bg-white border border-transparent hover:border-slate-200'}`}
            >
              <span className="truncate">{p.name}</span>
              <span className="text-[9px] opacity-70">({p.items.length})</span>
            </button>
          ))}
        </div>
      </div>

      <div className="p-6 space-y-8">
        {/* Search */}
        <div>
          <label className="text-xs font-bold text-slate-400 uppercase tracking-widest block mb-2">Search Catalog</label>
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="e.g. Maple, Oak..."
              value={filters.search}
              onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
              className="w-full bg-slate-50 border-slate-200 rounded-xl pl-10 pr-4 py-2 text-sm focus:ring-emerald-500"
            />
          </div>
        </div>

        {/* Intelligence Filters */}
        <div>
          <label className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2 mb-3">
            <Sparkles className="w-3 h-3 text-amber-500" />
            Ecological Discovery
          </label>
          <div className="grid grid-cols-1 gap-2">
            <button 
              onClick={() => setFilters(prev => ({ ...prev, onlyNative: !prev.onlyNative }))}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all border ${filters.onlyNative ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 'bg-white border-slate-100 text-slate-600'}`}
            >
              <Leaf className="w-4 h-4" />
              Native Species Only
            </button>
            <button 
              onClick={() => setFilters(prev => ({ ...prev, onlyFruiting: !prev.onlyFruiting }))}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all border ${filters.onlyFruiting ? 'bg-orange-50 border-orange-200 text-orange-700' : 'bg-white border-slate-100 text-slate-600'}`}
            >
              <Apple className="w-4 h-4" />
              Fruit Production
            </button>
            <button 
              onClick={() => setFilters(prev => ({ ...prev, onlyFlowering: !prev.onlyFlowering }))}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all border ${filters.onlyFlowering ? 'bg-amber-50 border-amber-200 text-amber-700' : 'bg-white border-slate-100 text-slate-600'}`}
            >
              <Plus className="w-4 h-4" />
              Ornamental Flowering
            </button>
          </div>
        </div>

        {/* Size Sliders */}
        <div className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <Ruler className="w-3 h-3" />
                Max Height
              </label>
              <span className="text-sm font-black text-emerald-600">{filters.maxHeight}'</span>
            </div>
            <input 
              type="range" min="5" max="80" step="5"
              value={filters.maxHeight}
              onChange={(e) => setFilters(prev => ({ ...prev, maxHeight: parseInt(e.target.value) }))}
              className="w-full accent-emerald-600 h-1 bg-slate-200 rounded-lg appearance-none"
            />
          </div>
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                <Ruler className="w-3 h-3" />
                Max Width
              </label>
              <span className="text-sm font-black text-emerald-600">{filters.maxWidth}'</span>
            </div>
            <input 
              type="range" min="5" max="80" step="5"
              value={filters.maxWidth}
              onChange={(e) => setFilters(prev => ({ ...prev, maxWidth: parseInt(e.target.value) }))}
              className="w-full accent-emerald-600 h-1 bg-slate-200 rounded-lg appearance-none"
            />
          </div>
        </div>

        {/* Categories */}
        <div>
          <label className="text-xs font-bold text-slate-400 uppercase tracking-widest block mb-3">Landscape Function</label>
          <div className="flex flex-wrap gap-2">
            {categories.map(cat => (
              <button 
                key={cat}
                onClick={() => setFilters(prev => ({ ...prev, categories: toggleList(prev.categories, cat) }))}
                className={`px-3 py-1.5 rounded-full text-[10px] font-black uppercase transition-all ${filters.categories.includes(cat) ? 'bg-emerald-600 text-white shadow-lg' : 'bg-white text-slate-500 border-slate-200 border'}`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
