
export type MonthStatus = 'dormant' | 'budding' | 'foliage' | 'fall-color';

export interface MonthData {
  status: MonthStatus;
  isFlowering: boolean;
  isFruiting: boolean;
}

export interface Tree {
  id: string;
  nursery: string;
  category: string;
  commonName: string;
  variety: string;
  scientificName: string;
  heightMin: number;
  heightMax: number;
  widthMin: number;
  widthMax: number;
  fallColor: string;
  waterNeeds: string;
  notes: string;
  publicApproved: string;
  // Derived Intelligence Fields
  isNative: boolean;
  hasFruit: boolean;
  hasFlowers: boolean;
  sunRequirement: 'Full Sun' | 'Partial' | 'Shade';
  soilPref: string[];
  // Phenology Data
  phenology: MonthData[];
}

export interface ProjectItem {
  treeId: string;
  designNotes: string;
  quantity: number;
}

export interface Project {
  id: string;
  name: string;
  items: ProjectItem[];
  createdAt: number;
}

export interface FilterState {
  search: string;
  categories: string[];
  nurseries: string[];
  maxHeight: number;
  maxWidth: number;
  waterNeeds: string[];
  isPublicApproved: boolean | null;
  // Advanced Filters
  onlyNative: boolean;
  onlyFruiting: boolean;
  onlyFlowering: boolean;
}
