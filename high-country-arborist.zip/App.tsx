
import React, { useState, useMemo, useEffect } from 'react';
import { trees } from './treeData';
import { Tree, FilterState, Project } from './types';
import Sidebar from './components/Sidebar';
import TreeGrid from './components/TreeGrid';
import PlantingAssistant from './components/PlantingAssistant';
import ScatterChart from './components/ScatterChart';
import ProjectDetail from './components/ProjectDetail';
import { TreePine, LayoutGrid, Info, BarChart3, Briefcase, Plus } from 'lucide-react';

const App: React.FC = () => {
  const [viewMode, setViewMode] = useState<'grid' | 'list' | 'chart' | 'project'>('grid');
  const [sortBy, setSortBy] = useState<'name' | 'height' | 'width' | 'native'>('name');
  
  // Projects State
  const [projects, setProjects] = useState<Project[]>(() => {
    const saved = localStorage.getItem('arborist_projects');
    return saved ? JSON.parse(saved) : [{ id: 'p1', name: 'My First Garden', items: [], createdAt: Date.now() }];
  });
  const [activeProjectId, setActiveProjectId] = useState<string>(projects[0].id);

  const activeProject = useMemo(() => projects.find(p => p.id === activeProjectId) || projects[0], [projects, activeProjectId]);

  const [filters, setFilters] = useState<FilterState>({
    search: '',
    categories: [],
    nurseries: [],
    maxHeight: 80,
    maxWidth: 80,
    waterNeeds: [],
    isPublicApproved: null,
    onlyNative: false,
    onlyFruiting: false,
    onlyFlowering: false,
  });

  useEffect(() => {
    localStorage.setItem('arborist_projects', JSON.stringify(projects));
  }, [projects]);

  const filteredTrees = useMemo(() => {
    return trees.filter(tree => {
      const matchesSearch = tree.commonName.toLowerCase().includes(filters.search.toLowerCase()) ||
                            tree.scientificName.toLowerCase().includes(filters.search.toLowerCase());
      const matchesCategory = filters.categories.length === 0 || filters.categories.includes(tree.category);
      const matchesNursery = filters.nurseries.length === 0 || filters.nurseries.includes(tree.nursery);
      const matchesHeight = tree.heightMax <= filters.maxHeight;
      const matchesWidth = tree.widthMax <= filters.maxWidth;
      const matchesWater = filters.waterNeeds.length === 0 || filters.waterNeeds.includes(tree.waterNeeds);
      const matchesNative = !filters.onlyNative || tree.isNative;
      const matchesFruit = !filters.onlyFruiting || tree.hasFruit;
      const matchesFlowering = !filters.onlyFlowering || tree.hasFlowers;
      
      let matchesPublic = true;
      if (filters.isPublicApproved === true) matchesPublic = tree.publicApproved.toLowerCase().startsWith('yes');
      else if (filters.isPublicApproved === false) matchesPublic = tree.publicApproved.toLowerCase().startsWith('no');

      return matchesSearch && matchesCategory && matchesNursery && matchesHeight && matchesWidth && matchesWater && matchesPublic && matchesNative && matchesFruit && matchesFlowering;
    }).sort((a, b) => {
      if (sortBy === 'name') return a.commonName.localeCompare(b.commonName);
      if (sortBy === 'height') return b.heightMax - a.heightMax;
      if (sortBy === 'width') return b.widthMax - a.widthMax;
      if (sortBy === 'native') return (b.isNative ? 1 : 0) - (a.isNative ? 1 : 0);
      return 0;
    });
  }, [filters, sortBy]);

  const handleToggleTreeInProject = (treeId: string) => {
    setProjects(prev => prev.map(p => {
      if (p.id !== activeProjectId) return p;
      const exists = p.items.find(i => i.treeId === treeId);
      if (exists) {
        return { ...p, items: p.items.filter(i => i.treeId !== treeId) };
      }
      return { ...p, items: [...p.items, { treeId, designNotes: '', quantity: 1 }] };
    }));
  };

  const handleUpdateProjectItem = (treeId: string, notes: string) => {
    setProjects(prev => prev.map(p => {
      if (p.id !== activeProjectId) return p;
      return {
        ...p,
        items: p.items.map(item => item.treeId === treeId ? { ...item, designNotes: notes } : item)
      };
    }));
  };

  const createProject = () => {
    const newId = `p-${Date.now()}`;
    const newP = { id: newId, name: 'Untitled Project', items: [], createdAt: Date.now() };
    setProjects([...projects, newP]);
    setActiveProjectId(newId);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row">
      <Sidebar 
        filters={filters} 
        setFilters={setFilters} 
        totalCount={filteredTrees.length}
        projects={projects}
        activeProjectId={activeProjectId}
        setActiveProjectId={setActiveProjectId}
        createProject={createProject}
      />

      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        <header className="bg-white border-b border-slate-200 p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2">
              <div className="p-2 bg-emerald-100 rounded-lg text-emerald-700">
                <TreePine className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-sm font-black text-slate-900 leading-tight">Arborist Engine</h1>
                <p className="text-[10px] text-emerald-600 font-black uppercase tracking-widest">Active: {activeProject.name}</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide">
            <div className="flex items-center bg-slate-100 rounded-xl p-1 shrink-0">
              <button onClick={() => setViewMode('grid')} className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${viewMode === 'grid' ? 'bg-white shadow-sm text-emerald-700' : 'text-slate-500'}`}><LayoutGrid className="w-3.5 h-3.5" />Grid</button>
              <button onClick={() => setViewMode('list')} className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${viewMode === 'list' ? 'bg-white shadow-sm text-emerald-700' : 'text-slate-500'}`}><Info className="w-3.5 h-3.5" />List</button>
              <button onClick={() => setViewMode('chart')} className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${viewMode === 'chart' ? 'bg-white shadow-sm text-emerald-700' : 'text-slate-500'}`}><BarChart3 className="w-3.5 h-3.5" />Analysis</button>
              <button onClick={() => setViewMode('project')} className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${viewMode === 'project' ? 'bg-white shadow-sm text-emerald-700' : 'text-slate-500'}`}><Briefcase className="w-3.5 h-3.5" />Project</button>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <select 
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="text-xs font-bold border-slate-200 rounded-xl focus:ring-emerald-500 bg-white"
              >
                <option value="name">Alpha A-Z</option>
                <option value="height">Size (Height)</option>
                <option value="width">Size (Width)</option>
                <option value="native">Native First</option>
              </select>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 lg:p-6 bg-slate-50">
          {viewMode === 'chart' ? (
            <ScatterChart trees={filteredTrees} />
          ) : viewMode === 'project' ? (
            <ProjectDetail 
              project={activeProject} 
              onUpdateNotes={handleUpdateProjectItem}
              onRemove={handleToggleTreeInProject}
            />
          ) : (
            <TreeGrid 
              trees={filteredTrees} 
              viewMode={viewMode}
              activeProjectItems={activeProject.items}
              onToggleProject={handleToggleTreeInProject}
            />
          )}
        </div>

        <div className="fixed bottom-6 right-6 z-40">
           <PlantingAssistant availableTrees={filteredTrees} />
        </div>
      </main>
    </div>
  );
};

export default App;
