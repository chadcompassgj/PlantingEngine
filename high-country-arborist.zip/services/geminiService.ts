
import { GoogleGenAI } from "@google/genai";
import { Tree } from "../types";

// Always use the process.env.API_KEY directly as per the coding guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getLandscapeAdvice = async (query: string, availableTrees: Tree[]) => {
  const treeContext = availableTrees.map(t => 
    `${t.commonName} (${t.scientificName}): ${t.notes}. Size: ${t.heightMax}'x${t.widthMax}'. Water: ${t.waterNeeds}.`
  ).join('\n');

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `
      User Query: ${query}
      
      Available Tree Database (Filtered):
      ${treeContext}
    `,
    config: {
      systemInstruction: `
        You are an expert landscape designer and arborist specializing in the Western Colorado region (Grand Junction, Fruita, Palisade). 
        Your goal is to help users select the best trees from the provided filtered database for their specific residential or public projects.
        Western Colorado is characterized by high-alkalinity soil, high-elevation sun, and low humidity. 
        Focus on ecological function (pollinators, shade), water conservation (Xeric vs Moderate), and urban adaptability.
        Be concise, professional, and friendly. 
        If specific Right-of-Way (ROW) restrictions are mentioned in the notes (like Ash prohibition), emphasize them.
      `,
      temperature: 0.7,
    },
  });

  // Correctly access the .text property from the response
  return response.text;
};
